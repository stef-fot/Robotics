umax = 0.2;
s1= sqrt(24^2 + 12^2);
s2 =24;
tmin1= s1/umax
tmin2= s2/umax
tf1= 250;
a2= (3.*s1) / tf1.^2
a3= -(2.*s1) / tf1.^3
t = 0:0.01:250;
x= (a2 * t.^2)+(a3 * t.^3);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('distance_0(m)','fontsize',18);

tf2= 200;
a2= (3.*s2) / tf2.^2
a3= -(2.*s2) / tf2.^3
t = 0:0.01:200;
x= (a2 * t.^2)+(a3 * t.^3);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('distance_f(m)','fontsize',18);

tf1= 250;
a2= (3.*s1) / tf1.^2;
a3= -(2.*s1) / tf1.^3;
a2=2*a2
a3=3*a3
t = 0:0.01:250;
x= (a2 * t)+(a3 * t.^2);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('distancedot_0(m/sec)','fontsize',18);



tf2= 200;
a2= (3.*s2) / tf2.^2;
a3= -(2.*s2) / tf2.^3;
a2=2*a2
a3=3*a3
t = 0:0.01:200;
x= (a2 * t)+(a3 * t.^2);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('distancedot_f(m/sec)','fontsize',18);