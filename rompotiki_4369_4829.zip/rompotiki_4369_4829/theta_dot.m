omega = 0.698132;
umax = 0.2;
s1= sqrt(24^2 + 12^2);
s2 =24;
theta1 = deg2rad(25.63)
theta2 = deg2rad(-90)
theta3 = deg2rad(138.34065963)
tmin1 = theta1/omega
tmin2 = theta2/omega
tmin3 = theta3/omega
#tmin1 = 0.6407
#tmin2 = 2.8907
#tmin3 = 5.7085
tf1= 2;
a2= (3.*theta1) / tf1.^2;
a3= -(2.*theta1) / tf1.^3;
a2=2*a2
a3=3*a3
t = 0:0.01:2;
x= (a2 * t)+(a3 * t.^2);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('thetadot_0(rad/sec)','fontsize',18);
#saveas(a,'theta_0.jpg');


tf2= 6;
a2= (3.*(theta2-theta1)) / tf2.^2;
a3= -(2.*(theta2-theta1)) / tf2.^3;
a2=2*a2
a3=3*a3
t = 0:0.01:6;
x= (a2 * t)+(a3 * t.^2);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('thetadot_u(rad/sec)','fontsize',18);
#saveas(a,'theta1.jpg');

tf3= 10;
a2= (3.*(theta3-theta2)) / tf3.^2;
a3= -(2.*(theta3-theta2)) / tf3.^3;
a2=2*a2
a3=3*a3
t = 0:0.01:10;
x= (a2 * t)+(a3 * t.^2);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('thetadot_f(rad/sec)','fontsize',18);
#saveas(a,'theta1.jpg');