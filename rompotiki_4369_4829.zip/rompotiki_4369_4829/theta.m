omega = 0.698132;
umax = 0.2;
s1= sqrt(24^2 + 12^2);
s2 =24;
theta1 = deg2rad(25.63)
theta2 = deg2rad(-90)
theta3 = deg2rad(138.34065963)
tmin1 = theta1/omega
tmin2 = theta2/omega
tmin3 = theta3/omega
#tmin1 = 0.6407
#tmin2 = -2.2500
#tmin3 = 3.4585
tf1= 2;
a2= (3.*theta1) / tf1.^2
a3= -(2.*theta1) / tf1.^3
t = 0:0.01:2;
x= (a2 * t.^2)+(a3 * t.^3);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('theta_0(rad)','fontsize',18);


tf2= 6;
a2= (3.*(theta2 - theta1)) / tf2.^2
a3= -(2.*(theta2 - theta1)) / tf2.^3
t = 0:0.01:6;
x= theta1+(a2 * t.^2)+(a3 * t.^3);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('theta_u(rad)','fontsize',18);

tf3= 10;
a2= (3.*(theta3 - theta2)) / tf3.^2
a3= -(2.*(theta3 - theta2)) / tf3.^3
t = 0:0.01:10;
x= theta2+(a2 * t.^2)+(a3 * t.^3);
a = figure();
plot(t,x)
xlabel('t(sec)','fontsize',18);
ylabel('theta_f(rad)','fontsize',18);
