# p3dx_gazebo
Pioneer 3DX model compatible with Gazebo and ROS environment
