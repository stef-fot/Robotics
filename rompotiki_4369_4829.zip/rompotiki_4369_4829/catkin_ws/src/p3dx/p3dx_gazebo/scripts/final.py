#!/usr/bin/env python3
import rospy
import time
import math
from geometry_msgs.msg import Twist

omega = 0.698132
umax = 0.2
s1= math.sqrt(24**2 + 12**2)
s2 =24
theta1 = math.radians(25.63)
theta2 = math.radians(-90)
theta3 = math.radians(138.34065963)
tmin1 = theta1/omega
tmin2 = theta2/omega
tmin3 = theta3/omega
tmin1= s1/umax
tmin2= s2/umax


class MyPath():
    def __init__(self):
        rospy.init_node('MyPath', anonymous=False)
        rospy.on_shutdown(self.shutdown)
        self.cmd_vel = rospy.Publisher('/pioneer/RosAria/cmd_vel', Twist, queue_size=1)
        rate=100
        
        r=rospy.Rate(rate)
        t=rospy.get_time()
        move_cmd=Twist()
        while(rospy.get_time()==0):
        	print("Akinito")
        print("Proti Peristrofiki Kinisi")
        while(rospy.get_time()-t<=2):
                theta1 = math.radians(25.63)
                tf1= 2
                a2= (3*theta1) / (tf1**2)
                a2 =2*a2
                #print(a2)
                a3= -(2*theta1) / (tf1**3)
                a3=3*a3
                #print(a3)
                move_cmd.angular.z = a2 *(rospy.get_time()-t)+ a3 *pow(rospy.get_time()-t,2)
                print("1st Angular Velocity: ",move_cmd.angular.z)
                self.cmd_vel.publish(move_cmd)
                r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()
        
        
        print("Proti Grammiki Kinisi")
        while((rospy.get_time()-t)<=250):
                tf1= 250;
                a2= (3*s1) / tf1**2
                a2=2*a2
                #print(a2)
                a3= -(2*s1) / tf1**3
                a3=3*a3
                #print(a3)
                move_cmd.linear.x=a2*((rospy.get_time()-t))+a3*pow((rospy.get_time()-t),2)  
                print("1st Linear Velocity: ",move_cmd.linear.x)
                self.cmd_vel.publish(move_cmd)
                r.sleep()
        	
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()
        
        
        print("Deuteri Peristrofiki Kinisi")
        while(rospy.get_time()-t<=6):
        	tf2= 6
	        a2= (3*(theta2-theta1)) / (tf2**2)
	        a2 =2*a2
	        #print(a2)
	        a3= -(2*(theta2-theta1)) / (tf2**3)
	        a3=3*a3
	        #print(a3)		


        	move_cmd.angular.z=a2 *(rospy.get_time()-t)+ a3 *pow(rospy.get_time()-t,2)
        	print("2nd Angular Velocity: ",move_cmd.angular.z)
        	self.cmd_vel.publish(move_cmd)
        	r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()  
        
        
        
        
           
        print("Deuteri Grammiki Kinisi")
        while(rospy.get_time()-t<=200):
                tf2= 200;
                a2= (3*s2) / tf2**2
                a2=2*a2
                #print(a2)
                a3= -(2*s2) / tf2**3
                a3=3*a3
                #print(a3)

                move_cmd.linear.x=a2*((rospy.get_time()-t))+a3*pow((rospy.get_time()-t),2) 
                print("2nd Linear Velocity: ",move_cmd.linear.x)
                self.cmd_vel.publish(move_cmd)
                r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()   
        
        print("Triti Peristrofiki Kinisi")
        while(rospy.get_time()-t<=10):
                tf3= 10
                a2= (3*(theta3-theta2)) / (tf3**2)
                a2 =2*a2
                #print(a2)
                a3= -(2*(theta3-theta2)) / (tf3**3)
                a3=3*a3
                #print(a3)
                move_cmd.angular.z=a2 *(rospy.get_time()-t)+ a3 *pow(rospy.get_time()-t,2)
                print("3rd Angular Velocity: ",move_cmd.angular.z)
                self.cmd_vel.publish(move_cmd)
                r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
         
        
               	
        	
    def shutdown(self):
        rospy.loginfo("Stopping the robot...")
        self.cmd_vel.publish(Twist())
        rospy.sleep(1)
if __name__ == '__main__':
    try:
        MyPath()
    except:
        rospy.loginfo("MyPath node terminated.")

  

