#!/usr/bin/env python3
import rospy
import time
from geometry_msgs.msg import Twist


class MyPath():
    def __init__(self):
        rospy.init_node('MyPath', anonymous=False)
        rospy.on_shutdown(self.shutdown)
        self.cmd_vel = rospy.Publisher('/pioneer/RosAria/cmd_vel', Twist, queue_size=1)
        rate=100
        
        r=rospy.Rate(rate)
        t=rospy.get_time()
        move_cmd=Twist()
        while(rospy.get_time()==0):
        	print("Akinito")
        print("Proti Peristrofiki Kinisi")
        while(rospy.get_time()-t<=2):
        	move_cmd.angular.z=0.6710*(rospy.get_time()-t)-0.3355*pow(rospy.get_time()-t,2)
        	print("1st Angular Velocity: ",move_cmd.angular.z)
        	self.cmd_vel.publish(move_cmd)
        	r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()
        
        
        print("Proti Grammiki Kinisi")
        while((rospy.get_time()-t)<=250):
        	move_cmd.linear.x=0.002576*((rospy.get_time()-t))-0.000010304*pow((rospy.get_time()-t),2)  
        	print("1st Linear Velocity: ",move_cmd.linear.x)
        	self.cmd_vel.publish(move_cmd)
        	r.sleep()
        	
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()
        
        
        print("Deuteri Peristrofiki Kinisi")
        while(rospy.get_time()-t<=6):
        	move_cmd.angular.z=-0.3364 *(rospy.get_time()-t)+0.056058*pow(rospy.get_time()-t,2)
        	print("2nd Angular Velocity: ",move_cmd.angular.z)
        	self.cmd_vel.publish(move_cmd)
        	r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()  
        
        
        
        
           
        print("Deuteri Grammiki Kinisi")
        while(rospy.get_time()-t<=200):
        	move_cmd.linear.x=0.0036*(rospy.get_time()-t)-0.000018*pow(rospy.get_time()-t,2)
        	print("2nd Linear Velocity: ",move_cmd.linear.x)
        	self.cmd_vel.publish(move_cmd)
        	r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
        t=rospy.get_time()   
        
        print("Triti Peristrofiki Kinisi")
        while(rospy.get_time()-t<=10):
        	move_cmd.angular.z=0.2392*(rospy.get_time()-t)-0.023912*pow(rospy.get_time()-t,2)
        	print("3rd Angular Velocity: ",move_cmd.angular.z)
        	self.cmd_vel.publish(move_cmd)
        	r.sleep()
        	
        	
        move_cmd = Twist()
        self.cmd_vel.publish(move_cmd)
        rospy.sleep(1)
         
        
               	
        	
    def shutdown(self):
        rospy.loginfo("Stopping the robot...")
        self.cmd_vel.publish(Twist())
        rospy.sleep(1)
if __name__ == '__main__':
    try:
        MyPath()
    except:
        rospy.loginfo("MyPath node terminated.")

  

