import math
omega = 0.698132
umax = 0.2
s1= math.sqrt(24**2 + 12**2)
s2 =24
theta1 = math.radians(25.63)
theta2 = math.radians(-90)
theta3 = math.radians(138.34065963)
tmin1 = theta1/omega
tmin2 = theta2/omega
tmin3 = theta3/omega
tmin1= s1/umax
tmin2= s2/umax
tf1= 2
a2= (3*theta1) / (tf1**2)
a2 =2*a2
print(a2)
a3= -(2*theta1) / (tf1**3)
a3=3*a3
print(a3)


    
tf2= 6
a2= (3*(theta2-theta1)) / (tf2**2)
a2 =2*a2
print(a2)
a3= -(2*(theta2-theta1)) / (tf2**3)
a3=3*a3
print(a3)


tf3= 10
a2= (3*(theta3-theta2)) / (tf3**2)
a2 =2*a2
print(a2)
a3= -(2*(theta3-theta2)) / (tf3**3)
a3=3*a3
print(a3)


tf1= 250;
a2= (3*s1) / tf1**2
a2=2*a2
print(a2)
a3= -(2*s1) / tf1**3
a3=3*a3
print(a3)


tf2= 200;
a2= (3*s2) / tf2**2
a2=2*a2
print(a2)
a3= -(2*s2) / tf2**3
a3=3*a3
print(a3)


